---
cssclasses:
  - noyaml
  - dashboard
  - wide-page
semestre: "[[2026-2]]"
coado_plano: demo-2026-2
data_prova: null
meta_semanal:
  minutos: 300
  questoes: 0
intervalos_revisao: [1, 7, 30]
cores:
  DEMO01: "#a8bfd4"
planejamento:
  tipo: ciclo
  minutos_semana: 300
  dias: [false, true, true, true, true, true, false]
  sessao_min: 30
  sessao_max: 90
  disciplinas:
    - codigo: DEMO01
      importancia: 2
      conhecimento: 2.5
  ciclo:
    - id: c1
      codigo: DEMO01
      minutos: 60
    - id: c2
      codigo: DEMO01
      minutos: 60
  ciclos_completos: 0
  inicio_ciclo: 2026-08-03
  empurrar_atrasados: true
topicos_concluidos: []
revisoes: []
---

# Estudo 2026-2

```datacorejsx
const { PainelEstudo } = await dc.require(dc.fileLink("System/Scripts/Widgets/dc-coadoPainel.jsx"));
return <PainelEstudo />;
```
