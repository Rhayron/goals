---
tags:
  - tipo/task
  - academico
class: "[[DEMO01 Sistemas de exemplo]]"
project:
  - "[[DEMO01 Sistemas de exemplo]]"
type: tarefa
status: in-progress
priority: normal
coado_disciplina: demo01
timeEntries: []
---

# DEMO01 · Estudo geral

Tarefa do TaskNotes para estudar [[DEMO01 Sistemas de exemplo]] quando não é uma entrega específica. Escolha esta tarefa no pomodoro: o tempo fica aqui e soma no projeto da disciplina nas estatísticas do TaskNotes.
