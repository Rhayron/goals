---
tags:
  - academico
categories:
  - "[[Disciplinas]]"
codigo: DEMO01
disciplina: Sistemas de exemplo
professor: ""
creditos: 4
semestre: 2026-2
type: disciplina
status: open
priority: normal
natureza: conteudo
conteudo_programatico:
  - id: t01
    nome: Introdução e modelagem
    aula: 1
  - id: t02
    nome: Resposta no tempo
    aula: 4
  - id: t03
    nome: Estabilidade
    aula: 8
---
# DEMO01 Sistemas de exemplo

Disciplina fictícia para o painel acadêmico abrir com dados. Não é uma matéria real.

## Avaliações

| Avaliação | Data | Peso |
|---|---|---|
| **Prova 1** | 24/09/2026 | 40% |
| **Prova 2** | 26/11/2026 | 60% |
