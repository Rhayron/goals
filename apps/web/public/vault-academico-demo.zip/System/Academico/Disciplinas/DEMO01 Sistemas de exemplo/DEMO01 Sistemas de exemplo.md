---
tags:
  - academico
categories:
  - "[[Disciplinas]]"
codigo: DEMO01
disciplina: Sistemas de exemplo
professor: ""
creditos: 4
semestre: 2026-2
type: disciplina
status: open
priority: normal
cssclasses:
  - dashboard
  - wide-page
natureza: conteudo
conteudo_programatico:
  - id: t01
    nome: Introdução e modelagem
    aula: 1
  - id: t02
    nome: Resposta no tempo
    aula: 4
  - id: t03
    nome: Estabilidade
    aula: 8
---

# DEMO01 - Sistemas de exemplo

```datacorejsx
const { ClassView } = await dc.require(dc.fileLink("System/Scripts/Widgets/dc-classView.jsx"));
return <ClassView />;
```

```datacorejsx
const { SubjectDashboard } = await dc.require(dc.fileLink("System/Scripts/Widgets/dc-subjectMetrics.jsx"));
return <SubjectDashboard />;
```

Disciplina fictícia para o painel acadêmico abrir com dados. Não é uma matéria real.

### Avaliações

| Data | Avaliação | Conteúdo cobrado |
|---|---|---|
| 24/09/2026 | **Prova 1** (40%) | Introdução e modelagem; Resposta no tempo |
| 26/11/2026 | **Prova 2** (60%) | Estabilidade |

![[Trabalhos de Curso.base#Por Disciplina|embed-clean]]
