---
type: disciplina
categories:
  - Disciplinas
tags:
  - disciplina
  - class
codigo: DEMO01
credits: 4
---
# DEMO01 Sistemas de exemplo

Disciplina fictícia para o painel acadêmico abrir com dados. Não é uma matéria real.
