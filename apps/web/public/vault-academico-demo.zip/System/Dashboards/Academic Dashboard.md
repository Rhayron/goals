---
cssclasses:
  - noyaml
tags:
  - dashboards
  - academico
due: 2025-12-31
status: todo
priority: high
nota: ""
type: tarefa
image:
---
```datacorejsx
const { PainelAcademico } = await dc.require(dc.fileLink("System/Scripts/Widgets/dc-academicoIntegrado.jsx"));
return <PainelAcademico />;
```

