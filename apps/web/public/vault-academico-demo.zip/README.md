# Vault acadêmica do Coado

Só o sistema acadêmico: painel, widgets, núcleo do Coado na vault, templates e uma disciplina de exemplo.

Não inclui notas pessoais, editais, PDFs nem o restante da vault.

Abra esta pasta como vault no Obsidian. Na primeira abertura, confirme a confiança da vault para os plugins da comunidade carregarem: o Obsidian guarda essa permissão fora da pasta. Eles já vão instalados, configurados e listados como habilitados.

Plugins: Datacore, Dataview, Templater, TaskNotes. O painel está em `System/Dashboards/Painel Academico.md`.
