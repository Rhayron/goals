# Vault acadêmica do Coado

Só o sistema acadêmico: painel, widgets, núcleo do Coado na vault, templates e uma disciplina de exemplo.

Não inclui notas pessoais, editais, PDFs nem o restante da vault.

Abra esta pasta como vault no Obsidian, com Datacore e Templater. O painel está em `System/Dashboards/Painel Academico.md`.
